*****************************************************************
*****************************************************************
***SAVE YOUR WORK BEFORE HITTING THE REBOOT AND FORCE SHUTDOWN***
*****************************************************************
*****************************************************************

I got tired of trying to fumble through so many options to reboot anything Windows 8, 8.1 and Windows Server 2012 related. I just simply through the commands in three buttons.

You can see I've included the source code and final application within each folder.

If you like, feel free to rename the project and etc...

All the best,

Jim Couts - Feel free to add me on LinkedIn: https://www.linkedin.com/profile/view?id=26673988 if you so desire!

###

CHANGELOG:

v1.0.0.0
11-13-2014:
First release

